/**
 * 
 */
package pregunta03;

/**
 * 
 */
public class Animal {

	private String name; // nombre del animal
	private int edad; // edad del animal
	private String raza; // raza del animal

	/**
	 * 
	 */
	public Animal() {
		// TODO Auto-generated constructor stub
	}

	// generar constructores

	// generar getters y setters

	// generar metodos que faltan

}
