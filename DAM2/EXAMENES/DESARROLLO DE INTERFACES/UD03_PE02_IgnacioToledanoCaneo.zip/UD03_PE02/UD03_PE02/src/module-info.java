/**
 * 
 */
/**
 * 
 */
module UD03_PE02 {
	requires java.desktop;
}