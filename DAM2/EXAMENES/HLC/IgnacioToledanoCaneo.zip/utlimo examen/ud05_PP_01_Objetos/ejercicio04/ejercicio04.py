

libro = None

while True:
    print("\nMENÚ PRINCIPAL")
    print("1. Crear libro")
    print("2. Mostrar libro")
    print("3. Mostrar número de páginas")
    print("4. Salir")

    opcion = input("Elige una opción: ")

    if opcion == "1":
        
        pass

    elif opcion == "2":
        
        pass

    elif opcion == "3":
        
        pass

    elif opcion == "4":
        break

    else:
        print("Opción incorrecta")
