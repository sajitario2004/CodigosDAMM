


persona = None

while True:
    print("\nMENÚ PRINCIPAL")
    print("1. Crear persona")
    print("2. Mostrar datos")
    print("3. Edad futura")
    print("4. Salir")

    opcion = input("Elige una opción: ")

    if opcion == "1":
        
        
        pass

    elif opcion == "2":
        
        pass

    elif opcion == "3":
        
        pass

    elif opcion == "4":
        break

    else:
        print("Opción incorrecta")
