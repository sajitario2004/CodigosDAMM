
cuenta = None

while True:
    print("\nMENÚ PRINCIPAL")
    print("1. Mostrar saldo")
    print("2. Ingresar dinero")
    print("3. Retirar dinero")
    print("4. Mostrar Historial")
    print("5. Salir")

    opcion = input("Elige una opción: ")

    if opcion == "1":
        # COMPLETAR
        pass

    elif opcion == "2":
        # COMPLETAR
        pass

    elif opcion == "3":
        # COMPLETAR
        pass
    
    elif opcion == "4":
        # COMPLETAR
        pass
    
    elif opcion == "5":
        break

    else:
        print("Opción incorrecta")
