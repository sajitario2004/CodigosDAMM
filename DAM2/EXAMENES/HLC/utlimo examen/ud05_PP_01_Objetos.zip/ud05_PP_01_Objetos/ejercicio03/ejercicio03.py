

animal = None

while True:
    print("\nMENÚ PRINCIPAL")
    print("1. Crear perro")
    print("2. Crear gato")
    print("3. Hacer hablar al animal")
    print("4. Salir")

    opcion = input("Elige una opción: ")

    if opcion == "1":
    
        pass

    elif opcion == "2":
        
        pass

    elif opcion == "3":
        
        pass

    elif opcion == "4":
        break

    else:
        print("Opción incorrecta")
