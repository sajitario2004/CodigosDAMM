class Animal:
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad= edad
        
    def hablar(self):
        print("HACE UN SONIDO")
        
    def show_me(self):
        txt = f"El nombre es: {self.nombre} y la edad es {self.edad}"
        return txt
    
       
        