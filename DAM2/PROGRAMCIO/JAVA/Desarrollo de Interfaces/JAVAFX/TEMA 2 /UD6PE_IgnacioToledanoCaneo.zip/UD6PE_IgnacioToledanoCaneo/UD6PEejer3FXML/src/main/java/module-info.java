module es.dam.ud6peejer3fxml {
    requires javafx.controls;
    requires javafx.fxml;

    opens es.dam.ud6peejer3fxml to javafx.fxml;
    exports es.dam.ud6peejer3fxml;
}
