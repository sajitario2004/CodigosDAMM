package es.dam.ud6peejer2simple;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * JavaFX App
 */
public class App extends Application {

    @Override
    public void start(Stage stage) {

        // 1. Crear la Barra de Menú principal (La tira gris de arriba)
        MenuBar menuBar = new MenuBar();

        // 2. Crear los Menús principales (File, Edit, Help)
        Menu menuFile = new Menu("File");
        Menu menuEdit = new Menu("Edit");
        Menu menuHelp = new Menu("Help");

        // 3. Crear los Items para el menú "File" (New, Open File, Exit)
        MenuItem itemNew = new MenuItem("New");
        MenuItem itemOpen = new MenuItem("Open File");
        MenuItem itemExit = new MenuItem("Exit");
        
        // (Opcional) Darle acción al botón salir
        itemExit.setOnAction(e -> System.exit(0));

        // 4. Agregar los items dentro del menú "File"
        menuFile.getItems().addAll(itemNew, itemOpen, itemExit);

        // 5. Agregar los tres menús a la Barra Principal
        menuBar.getMenus().addAll(menuFile, menuEdit, menuHelp);

        // 6. Layout Principal
        // Usamos BorderPane porque tiene una posición explícita para menús (.setTop)
        BorderPane root = new BorderPane();
        root.setTop(menuBar);

        // 7. Configuración de la Escena
        Scene scene = new Scene(root, 400, 300);
        stage.setTitle("JavaFX Menu (o7planning.org) - CODE");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}