
<?xml version="1.0" encoding="UTF-8"?>
<helpset version="2.0">
<title>Ayuda de la aplicación</title>
<maps>
<homeID>inicio</homeID>
<mapref location="ayuda.map" />
</maps>
<view>
<name>TOC</name>
<label>Contenido</label>
<type>javax.help.TOCView</type>
<data>ayuda.toc</data>
</view>
</helpset>