""" 
4-3.Contando hasta veinte: use un bucle for para imprimir los números del 1 al 20,
inclusivo.
"""
[print(i) for i in range(1, 21)]

