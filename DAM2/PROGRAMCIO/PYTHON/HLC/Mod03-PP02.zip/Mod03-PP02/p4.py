""" 
4-4. Un millón: haz una lista de los números del uno al un millón y luego
use un bucle for para imprimir los números. (Si la salida tarda demasiado, deténgala
presionando CTRL-C o cerrando la ventana de salida).
"""

[print(i) for i in range(1, 1000001)]