""" 
4-5. Sumar un millón: haz una lista de los números del uno al un millón y
luego use min() y max() para asegurarse de que su lista realmente comience en uno y termine
en un millón. Además, use la función sum() para ver qué tan rápido Python puede agregar
un millón de números.
"""


print(min(range(1, 1000001)),max(range(1, 1000001)))



