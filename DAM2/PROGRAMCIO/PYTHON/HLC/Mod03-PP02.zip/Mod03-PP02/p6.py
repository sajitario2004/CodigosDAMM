""" 
4-6. Números impares: utilice el tercer argumento de la función range() para hacer una lista
de los números impares del 1 al 20. Utilice un bucle for para imprimir cada número.
"""

[print(i) for i in range(1, 21, 2)]