""" 
4-8. Cubos: Un número elevado a la tercera potencia se llama cubo. Por ejemplo,
el cubo de 2 se escribe como 2**3 en Python. Haz una lista de los primeros 10 cubos (que
es decir, el cubo de cada número entero del 1 al 10) y utilice un bucle for para imprimir
el valor de cada cubo.
"""

[print(i**3) for i in range(1, 11)]
    

