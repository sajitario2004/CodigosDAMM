""" 
4-9. Comprensión de cubos: utilice una lista de comprensión para generar una lista de los primeros
10 cubos.
"""

cubes = [i**3 for i in range(1, 11)]
for cube in cubes:
    print(cube)
    