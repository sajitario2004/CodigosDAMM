def make_shirt(size, message):
    print(f"Shirt withc siza: {size}")
    print(f"Message to print: {message}")
    
def __main__():
    make_shirt(size="XL", message="No se traducir")
    