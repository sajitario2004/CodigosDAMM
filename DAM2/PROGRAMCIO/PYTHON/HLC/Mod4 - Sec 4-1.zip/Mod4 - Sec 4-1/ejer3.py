def describe_city(name_city, country):
    print(f"{name_city} is in {country}")
    
    
describe_city(name_city="Madrid", country="ESPAÑAA")