import printing_models

#He importado la funcion de printing texto
printing_models.printing_texto("Dodecagono")