def function_name(a, b):
    return a+b