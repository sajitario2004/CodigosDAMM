def printing_texto(str):
    print(f"Printing model: {str}")